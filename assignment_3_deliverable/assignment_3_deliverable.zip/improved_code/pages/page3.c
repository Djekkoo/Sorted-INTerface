#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {

    char buffer[4];
    buffer[4] = 'a'; // buffer overflow

}