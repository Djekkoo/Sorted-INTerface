#include <stdio.h>

void test(FILE* printFile);
